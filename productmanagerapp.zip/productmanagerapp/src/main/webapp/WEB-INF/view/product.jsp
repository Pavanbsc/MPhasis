<%@page import="java.util.List"%>
<%@page import="com.mphasis.productmanagerapp.model.ProductModel"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Products page</title>
<link href="style.css" rel="stylesheet">
</head>
<body>
	<jsp:include page="menu.jsp"></jsp:include>
	<center>
 <h3>Products</h3>
 <% List<ProductModel> products = (List<ProductModel>)
 									request.getAttribute("products");%>
 
 <table border="2px" width="500px" border-collapse: collapse;>
  <tr>
   <th>Name</th>
   <th>id</th>
   <th>Product</th>
   <%
     for(ProductModel p : products){
   %>
   <tr>
   <td><%=p.getName() %></td>
    <td><%=p.getId() %></td>
     <td><%=p.getPrice() %></td>
  </tr>
  <%
     }
  %>
 </table>
 </center>
</body>
</html>